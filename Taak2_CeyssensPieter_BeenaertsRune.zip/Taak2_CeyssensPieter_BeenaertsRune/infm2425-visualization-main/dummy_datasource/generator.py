import paho.mqtt.client as mqtt
import json
import time
import random

# MQTT Broker Configuration
MQTT_BROKER = "mosquitto"
MQTT_PORT = 1883

# MQTT Client
class MQTTClient:
    def __init__(self, broker, port):
        self.client = mqtt.Client()
        self.client.on_connect = self.on_connect
        self.client.connect(broker, port, 60)

    def on_connect(self, client, userdata, flags, rc):
        print(f"Connected to MQTT broker with code {rc}")

    def publish(self, topic, payload):
        self.client.publish(topic, json.dumps(payload))

    def loop(self):
        self.client.loop_start()

class SpeedSensor:
    def __init__(self, sensor_id, initial_speed=0.0):
        self.sensor_id = sensor_id
        self.speed = initial_speed

    def measure(self):
        return self.speed

    def update_speed(self, delta):
        self.speed = max(0.0, min(50.0, self.speed + delta))

class BatterySensor:
    def __init__(self, sensor_id, initial_battery=100.0):
        self.sensor_id = sensor_id
        self.battery = initial_battery

    def measure(self):
        return self.battery

    def update_battery(self, delta):
        self.battery = max(0.0, min(100.0, self.battery + delta))

class MotorActuator:
    def __init__(self, actuator_id, initial_state="idle"):
        self.actuator_id = actuator_id
        self.state = initial_state

    def accelerate(self):
        self.state = "accelerate"

    def decelerate(self):
        self.state = "decelerate"

    def idle(self):
        self.state = "idle"

class RangeActuator:
    def __init__(self, actuator_id, initial_range=500):
        self.actuator_id = actuator_id
        self.range = initial_range

    def update_range(self, battery_percentage):
        self.range = battery_percentage * 5

    def get_range(self):
        return self.range

class PLCLogic:
    def __init__(self, speed_sensor, battery_sensor, motor, range_actuator):
        self.speed_sensor = speed_sensor
        self.battery_sensor = battery_sensor
        self.motor = motor
        self.range_actuator = range_actuator

    def process(self):
        action = random.choices(['constant', 'accelerate', 'decelerate'], weights=[0.6, 0.2, 0.2])[0]
        if action == 'constant':
            self.motor.idle()
        elif action == 'accelerate':
            self.motor.accelerate()
        else:
            self.motor.decelerate()

        self.__simulate_physics_step()

        self.range_actuator.update_range(self.battery_sensor.measure())

    def __simulate_physics_step(self):
        if self.motor.state == "accelerate":
            self.speed_sensor.update_speed(random.uniform(1, 5))
        elif self.motor.state == "decelerate":
            self.speed_sensor.update_speed(-random.uniform(1, 5))

        current_speed = self.speed_sensor.measure()
        base_consumption = 0.1 * (current_speed / 50.0)
        acceleration_consumption = 0.2 * (current_speed / 50.0) ** 2 if self.motor.state == "accelerate" else 0
        regeneration = 0.06 * (current_speed / 50.0) if self.motor.state == "decelerate" else 0
        total_consumption = base_consumption + acceleration_consumption - regeneration
        self.battery_sensor.update_battery(-total_consumption)

def simulation_loop():
    speed_sensor = SpeedSensor(sensor_id="speed_sensor_01", initial_speed=0.0)
    battery_sensor = BatterySensor(sensor_id="battery_sensor_01", initial_battery=100.0)
    motor = MotorActuator(actuator_id="motor_01", initial_state="idle")
    range_actuator = RangeActuator(actuator_id="range_actuator_01", initial_range=500)

    plc = PLCLogic(speed_sensor, battery_sensor, motor, range_actuator)
    mqtt_client = MQTTClient(MQTT_BROKER, MQTT_PORT)
    mqtt_client.loop()

    while True:
        site = "site1"

        plc.process()

        mqtt_client.publish(f"factory/{site}/sensor/{speed_sensor.sensor_id}/speed", {
            "value": speed_sensor.measure(),
            "unit": "km/h",
        })
        mqtt_client.publish(f"factory/{site}/sensor/{battery_sensor.sensor_id}/battery", {
            "value": battery_sensor.measure(),
            "unit": "%",
        })
        mqtt_client.publish(f"factory/{site}/actuator/{motor.actuator_id}/status", {
            "state": motor.state,
        })
        mqtt_client.publish(f"factory/{site}/actuator/{range_actuator.actuator_id}/range", {
            "value": range_actuator.get_range(),
            "unit": "km",
        })

        time.sleep(0.5)

if __name__ == "__main__":
    simulation_loop()
